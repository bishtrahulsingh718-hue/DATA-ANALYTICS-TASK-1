import pandas as pd

# Load raw dataset
df = pd.read_csv("raw_customer_data.csv")

# Clean column names
df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]

# Standardize text
df["customer_name"] = df["customer_name"].str.strip()
df["gender"] = df["gender"].replace({
    "M": "Male", "F": "Female",
    "male": "Male", "female": "Female"
})
df["country"] = df["country"].replace({
    "INDIA": "India", "india": "India", "IND": "India"
})

# Convert data types
df["age"] = pd.to_numeric(df["age"], errors="coerce")
df["join_date"] = pd.to_datetime(df["join_date"], errors="coerce")
df["salary"] = pd.to_numeric(df["salary"], errors="coerce")

# Remove duplicate records
df = df.drop_duplicates()

# Handle missing values
df["age"] = df["age"].fillna(df["age"].median()).astype(int)
df["salary"] = df["salary"].fillna(df["salary"].median())
df["gender"] = df["gender"].fillna(df["gender"].mode()[0])
df["join_date"] = df["join_date"].fillna(pd.Timestamp("2026-01-01"))

# Standardize date format
df["join_date"] = df["join_date"].dt.strftime("%d-%m-%Y")

# Save cleaned dataset
df.to_csv("cleaned_customer_data.csv", index=False)

print("Data cleaning completed successfully.")
print(df.info())
