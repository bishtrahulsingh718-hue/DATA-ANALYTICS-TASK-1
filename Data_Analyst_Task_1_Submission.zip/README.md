# Data Analyst Internship – Task 1
## Data Cleaning and Preprocessing

### Dataset
Customer data containing customer ID, name, gender, country, age, join date, salary and email.

### Changes Made
1. Removed leading/trailing spaces from names and column headers.
2. Standardized column names to lowercase with underscores.
3. Standardized gender values (M/F/male/female) to Male/Female.
4. Standardized country values (IND, INDIA, india) to India.
5. Converted Age and Salary to numeric data types.
6. Converted Join Date to a consistent date format.
7. Removed one duplicate record.
8. Filled missing numeric values using the median.
9. Filled missing gender using the mode.
10. Filled missing date with a defined default date where parsing produced a missing value.
11. Exported the cleaned dataset as CSV.

## Interview Questions

### 1. What are missing values and how do you handle them?
Missing values are fields where data is not available. They can be handled by removing rows/columns when appropriate or imputing values using mean, median, mode, forward fill, or another suitable business rule.

### 2. How do you treat duplicate records?
First identify duplicates using `duplicated()`. If they represent repeated records rather than legitimate repeated events, remove them using `drop_duplicates()`.

### 3. Difference between dropna() and fillna() in Pandas?
`dropna()` removes rows or columns containing missing values. `fillna()` replaces missing values with a specified value or calculated value such as a mean, median or mode.

### 4. What is outlier treatment and why is it important?
Outlier treatment means identifying unusually high or low observations and deciding whether they are valid, errors, or require transformation/capping/removal. It is important because extreme values can distort analysis and statistical results.

### 5. Explain the process of standardizing data.
Standardization makes values consistent across a dataset. Examples include converting Male/M/male to one value, using one country naming convention, applying one date format, and making column names uniform.

### 6. How do you handle inconsistent data formats?
I first inspect the column values, then convert them to a common data type. For dates, Pandas `to_datetime()` can be used; for numeric columns, `to_numeric()` can be used. Invalid values are reviewed and handled appropriately.

### 7. What are common data cleaning challenges?
Common challenges include missing values, duplicate records, inconsistent spelling/capitalization, incorrect data types, invalid dates, outliers, inconsistent units, and unexpected or corrupted values.

### 8. How can you check data quality?
I check null counts, duplicate counts, data types, unique values, value ranges, date validity, formatting consistency and basic descriptive statistics. I also compare the data before and after cleaning to confirm that the changes are correct.

## Tools Used
- Python
- Pandas
- CSV
- Jupyter Notebook / VS Code compatible

## Files
- `raw_customer_data.csv` – raw dataset
- `cleaned_customer_data.csv` – cleaned dataset
- `data_cleaning.py` – preprocessing code
- `README.md` – project explanation
